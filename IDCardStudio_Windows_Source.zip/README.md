# ID Card Generator Pro - Visual WYSIWYG & Batch Studio

Aplikasi visual desktop interaktif berbasis **PyQt6** dan **Pillow** untuk mendesain template ID Card secara WYSIWYG (Drag & Drop), melakukan pratinjau live data, dan mengekspor kartu satuan maupun cetak massal (Batch Grid A4 3x3 @ 300 DPI) siap cetak percetakan.

---

## 🌟 Fitur Utama

1. **Interactive WYSIWYG Template Canvas (Drag & Drop)**:
   - Muat gambar background template apa pun (PNG, JPG, WebP).
   - Tambah elemen Layer dinamis:
     - **Dynamic Text**: Nama Karyawan, NIK, Divisi, Jabatan, dll.
     - **Foto Profil Frame**: Placeholder frame foto dengan opsi crop/contain/cover, radius sudut membulat, dan garis tepi (*border*).
   - Drag & Drop langsung di atas kanvas dengan mouse untuk memposisikan elemen secara visual.
   - Resize handle interaktif pada sudut elemen atau atur koordinat presisi via panel properti.
   - **Simpan & Muat Preset Template** (Format `.json` atau `.yaml`).

2. **Tipografi & Smart Font Fitting**:
   - Pilihan font kustom (`.ttf`, `.otf`) atau font sistem.
   - Penyesuaian ukuran font, warna teks (Color Picker terintegrasi), alignment (Kiri, Tengah, Kanan), gaya Bold/Italic/UPPERCASE.
   - **Smart Auto-Fit Width**: Jika nama/teks panjang melebihi lebar batas kanan kotak, sistem otomatis mengecilkan ukuran font secara bertahap sampai batas minimal (*min font size*) agar teks tidak terpotong atau keluar dari kartu.

3. **Input Data Dinamis & Fleksibel (Tanpa Excel Kaku)**:
   - **Mode Form Satuan**: Form dinamis yang otomatis menyesuaikan dengan daftar layer template. Ketik nama, NIK, pilih foto lokal -> *Live Preview* langsung berubah di samping secara instan -> Tombol *Export Kartu Ini*.
   - **Mode Batch Import**:
     - Tabel interaktif langsung di aplikasi.
     - **Paste dari Clipboard**: Cukup salin (*Ctrl+C*) data tabel dari Excel atau Google Sheets, lalu klik tombol **📋 Paste dari Clipboard**.
     - Impor file CSV.
     - Tombol **👁️ Preview Baris di Kanvas**: Cek tampilan kartu tiap orang sebelum dicetak.

4. **Integrasi Background Removal (remove.bg)**:
   - Dukungan API remove.bg untuk menghapus latar belakang foto profil secara otomatis.
   - Dilengkapi sistem cache lokal (*file-hash based*) sehingga foto yang sama tidak membuang kuota API saat dirender ulang.

5. **Export & Layout Cetak Percetakan**:
   - **Export Satuan**: Simpan ke PNG / JPEG dengan metadata resolusi tinggi 300 DPI.
   - **Export Batch Grid A4 PDF**: Menggabungkan hasil batch ke lembar A4 (grid 3x3 / 9 kartu per halaman) dengan margin simetris dan garis potong (*L-shape crop marks*) yang presisi untuk pisau potong/guillotine percetakan.
   - **Multi-threading Penuh**: Seluruh rendering batch dijalankan di background thread (`QThread`) sehingga antarmuka pengguna (GUI) tetap mulus tanpa *freeze*, dilengkapi dengan *progress bar*, persentase, dan log status langsung.

---

## 📂 Struktur Modul Kode

```
├── models.py                # Data classes LayerConfig & TemplateConfig, serialisasi JSON/YAML
├── generator_engine.py      # Core Pillow 300 DPI renderer, smart font fitting, background removal, dan A4 PDF builder
├── canvas_editor.py         # QGraphicsScene/QGraphicsView WYSIWYG drag-drop canvas & layer property panel
├── main.py                  # PyQt6 Window utama, tab visual editor, form manual, tabel batch, & worker threads
├── idcard.py                # Unified entry point (bisa GUI maupun headless CLI)
├── sample_data/             # Contoh aset template, foto avatar, preset JSON, dan data CSV
│   ├── sample_template.png  # Background template kartu CR80 (638 x 1011 px @ 300 DPI)
│   ├── sample_preset.json   # Preset konfigurasi layer default
│   ├── sample_photo.png     # Foto avatar contoh
│   └── sample_batch.csv     # Data 9 pegawai contoh
└── test_suite.py            # Unit test otomatis
```

---

## 🚀 Cara Menjalankan

### 1. Menjalankan Aplikasi Desktop (GUI):
```bash
python3 main.py
# atau
python3 idcard.py
```

### 2. Menjalankan Batch Export via CLI (Opsi Headless / Terminal):
```bash
python3 idcard.py --cli --preset sample_data/sample_preset.json --csv sample_data/sample_batch.csv --output hasil_cetak_a4.pdf
```

### 3. Menjalankan Unit Test:
```bash
python3 test_suite.py
```

---

## 📋 Panduan Penggunaan Alur Kerja

1. **Buka Aplikasi**: Tab pertama (*Template Editor*) akan otomatis memuat template standar Nusantara Tech.
2. **Atur Desain (WYSIWYG)**:
   - Geser foto atau teks langsung di kanvas.
   - Klik salah satu elemen untuk mengubah font, warna, ukuran, atau alignment pada panel kanan.
   - Gunakan tombol **💾 Simpan Preset** untuk menyimpan layout template Anda.
3. **Cetak Satuan**:
   - Pindah ke tab **👤 Input Data Satuan**.
   - Masukkan nama karyawan, NIK, dan pilih file foto.
   - Perhatikan perubahan langsung pada *Live Preview*.
   - Klik **💾 Export Kartu Ini ke Gambar**.
4. **Cetak Massal (Batch Grid A4)**:
   - Pindah ke tab **📋 Batch Import & Cetak A4**.
   - Salin tabel dari spreadsheet Anda, lalu klik **📋 Paste dari Clipboard** (atau klik **📂 Import CSV File**).
   - Klik **🖨️ Export Batch ke A4 PDF (Grid 3x3 Siap Cetak)**.
   - File PDF 300 DPI siap diserahkan ke percetakan!
